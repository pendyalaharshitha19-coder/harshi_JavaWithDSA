package premitiveandnonpremitive;

public class SingleLinkedList {

	static class Node {
        int data;
        Node next;

        Node(int data) {
            this.data = data;
            this.next = null;
        }
    }

    Node head = null;

    public void insert(int data) {
        Node newNode = new Node(data);
        if (head == null) {
            head = newNode;  // Fixed the assignment
        } else {
            Node temp = head;
            while (temp.next != null) {
                temp = temp.next;
            }
            temp.next = newNode;  // Fixed missing semicolon
        }
    }

    public void delete(int value) {
        if (head == null) {
            System.out.println("List is empty!");
            return;
        }
        if (head.data == value) {
            head = head.next;
            return;
        }

        Node current = head;
        Node previous = null;
        while (current != null && current.data != value) {
            previous = current;
            current = current.next;
        }

        if (current == null) {
            System.out.println("Value not found!");
            return;
        }

        previous.next = current.next;  // Fixed typo: "curent" to "current"
    }

    public boolean search(int key) {  // Fixed typo: "bolean" to "boolean"
        Node temp = head;
        while (temp != null) {
            if (temp.data == key) {
                return true;
            }
            temp = temp.next;
        }
        return false;
    }

    public void display() {
        if (head == null) {
            System.out.println("List is empty.");
            return;
        }
        Node temp = head;
        System.out.print("Linked List: ");
        while (temp != null) {
            System.out.print(temp.data + " ");
            temp = temp.next;
        }
        System.out.println("NULL");
    }

    public static void main(String[] args) {
        SingleLinkedList list = new SingleLinkedList();  // Fixed class name
        list.insert(10);
        list.insert(20);
        list.insert(30);
        list.insert(40);
        list.display();  // Fixed missing semicolon
        System.out.println("Searching 30: " + list.search(30));
        list.delete(20);
        list.display();
        list.delete(10);
        list.display();
        list.insert(40);
        list.display();
        System.out.println("Searching 30: " + list.search(30));
        list.delete(20);
        list.display();
        list.delete(10);
        list.display();
    }
}
