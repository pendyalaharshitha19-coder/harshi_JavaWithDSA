package premitiveandnonpremitive;

public class DoubleLinkedList {
	
		static class Node{
			  int data;
			  Node prev;
			  Node next;
			  Node(int data){
				  this.data=data;
			  }
		  }
		  Node head=null;
		  Node tail=null;
		  public void insert(int data) {
			  Node newNode= new Node(data);
			   
			  if (head == null) {
				  head = tail = newNode;
			  } else {
				  tail.next =newNode;
				  newNode.prev=tail;
				  tail=newNode;
			  }
		  }
		  public void delete(int value) {
			  if (head == null) {
				  System.out.println("list is empty!");
				  return; 
			  }
			  Node current = head;
			  while (current !=null && current.data !=value) {
				  current=current.next;
			  }
			  if (current == null) {
				  System.out.println("value not found!");
				  return;
			  }
			  if (current == head) {
				  head =head.next;
				  if(head !=null) head.prev=null;
			  }
			  else if (current == tail) {
				  tail=tail.prev;
				  tail.next=null;
			  }
			  else {
				  current.prev.next=current.next;
				  current.next.prev=current.prev;
				  
			  }
		  }
		  public boolean search(int key) {
			  Node temp=head;
			  while (temp!=null) {
				  if (temp.data== key) return true;
				  temp=temp.next;
			  }
			  return false;
		  }
		  public void displayForward() {
			  Node temp=head;
			  System.out.print("forward:");
			  while (temp!=null) {
				  System.out.print(temp.data+" ");
				  temp=temp.next;
			  }
			  System.out.println("NULL");
		  }
		  public void displayBackward() {
			  Node temp=tail;
			  System.out.print("backward:");
			  while(temp !=null) {
				  System.out.print(temp.data+" ");
				  temp=temp.prev;
			  }
			  System.out.println("NULL");
		  }
		  public static void main(String[] args) {
			  DoubleLinkedList dll=new  DoubleLinkedList();
			  dll.insert(10);
			  dll.insert(20);
			  dll.insert(30);
			  dll.insert(40);
			  dll.displayForward();
			  dll.displayBackward();
			  System.out.println("Searching 30: " + dll.search(30));
			  System.out.println("Searching 50: " + dll.search(50));
			  dll.delete(20);
			  dll.displayForward();
			  dll.delete(10);
			  dll.displayForward();
			  dll.delete(40);
			  dll.displayForward();
			  
		  }

		}