package premitiveandnonpremitive;

public class stackprogram {
	public class StackProgram {
		private int maxsize;
		private int[] stackArray;
		private int top;
		//constructor
		public StackProgram(int size) {
			
			maxsize=size;
			 stackArray = new int [maxsize];
			top=-1;
		}
		public StackProgram() {
			// TODO Auto-generated constructor stub
		}
		//push operation
		public void push(int value) {
			if(top>=maxsize -1) {
				System.out.println("stack overflow!");
				return;
			}
			stackArray[++top]=value;
			System.out.println("pushed :" +value) ;
		}
		//pop operation
		public int pop() {
			  if (isEmpty() ) {
				System.out.println("stack underflow!");
				return-1;
			  }
			  return stackArray[top--];
		}
		private boolean isEmpty() {
			// TODO Auto-generated method stub
			return false;
		}
		//peak operation
		public int peek() {
			if (isEmpty()) {
				System .out.println("stack isempty!");
				return -1;
			}
			return stackArray[top];
		}
		//is empty check
		public boolean isempty()
		{return top==-1;
		}
		//display stack
		public void display() {
			System.out.print("stack: ");
			for(int i=0;i<=top;i++) {
				System.out.print(stackArray[i]+" ");
			}
			System.out.println();
		}
		//main method for testing
		public static void main(String[]args) {
			StackProgram stack=new StackProgram(5);
			stack.push(10);
			stack.push(20);
			stack.push(30);
			stack.display();
			
			System.out.println("peek: "+ stack.peek());
			System.out.println("popped: "+stack.pop());
			stack.display();
			System.out.println("Is empty? "+stack.isEmpty());
		}
		}
}
