package javapracticeprogram;
public class Arithmeticoperations {
    public static void main(String[] args) {
        // Declare two integer variables
        int num1 = 20;
        int num2 = 5;

        // Perform arithmetic operations
        int sum = num1 + num2;        // Addition
        int difference = num1 - num2; // Subtraction
        int product = num1 * num2;    // Multiplication
        int quotient = num1 / num2;   // Division
        int remainder = num1 % num2;  // Modulus (remainder after division)

        // Print the results
        System.out.println("Number 1: " + num1);
        System.out.println("Number 2: " + num2);
        System.out.println("Sum: " + sum);
        System.out.println("Difference: " + difference);
        System.out.println("Product: " + product);
        System.out.println("Quotient: " + quotient);
        System.out.println("Remainder: " + remainder);
    }
}