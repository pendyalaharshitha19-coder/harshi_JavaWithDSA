package javapracticeprogram;

public class PackageInfo {

}
