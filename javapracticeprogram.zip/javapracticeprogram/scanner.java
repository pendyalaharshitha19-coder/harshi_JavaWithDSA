package javapracticeprogram;

public class scanner {

	public static void main(String[] args) {
		          scanner scanner = new Scanner(System.in);
		        System.out.print("Enter your name: ");
		        String name = scanner.nextLine(); 
		        System.out.print("Enter your age: ");
		        int age = scanner.nextInt(); 
		        scanner.nextLine(); 
		        System.out.print("Enter your favorite color: ");
		        String color = scanner.nextLine(); 
		        System.out.println("\nHello, " + name + "!");
		        System.out.println("You are " + age + " years old.");
		        System.out.println("Your favorite color is " + color + ".");
		        scanner.close();
		    }
		}
