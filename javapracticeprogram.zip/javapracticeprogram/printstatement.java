
package javapracticeprogram;
  public class Simple Print {
    public static void main(String[] args) {
        // This line prints "Hello, Java!" to the console, followed by a new line.
        System.out.println("Hello, Java!"); 
    }
}
