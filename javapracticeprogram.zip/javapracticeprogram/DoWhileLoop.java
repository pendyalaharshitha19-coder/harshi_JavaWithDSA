package javapracticeprogram;

public class DoWhileLoop {
	public class DoWhileExample {
	    public static void main(String[] args) {
	        int count = 1; // Initialize the counter

	        // The do-while loop starts here
	        do {
	            System.out.println("Current count: " + count); // Execute body
	            count++; // Increment the counter
	        } while (count <= 5); // Check the condition after execution

	        System.out.println("Loop finished. Final count: " + count);
	    }
	}

}
