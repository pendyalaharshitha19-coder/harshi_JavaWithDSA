package javapracticeprogram;

public class IfCondition {
    public static void main(String[] args) {
        // Declare and initialize an integer variable
        int number = 7;

        // Use an if statement to check if the number is greater than 0
        if (number > 0) {
            // This block of code will execute only if the condition (number > 0) is true
            System.out.println("The number " + number + " is positive.");
        }

        // This statement will always execute, regardless of the if condition
        System.out.println("Program finished checking the number.");
    }
}
