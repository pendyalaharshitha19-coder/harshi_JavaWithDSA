
package JavaPracriceProgram;
public class OverrideDemo {
    public static void main(String[] args) {
        Animal myAnimal = new Animal();
        myAnimal.sound();  // Calls Animal's sound()

        Dog myDog = new Dog();
        myDog.sound();     // Calls Dog's overridden sound()

        // Polymorphism: reference type is Animal but object is Dog
        Animal anotherDog = new Dog();
        anotherDog.sound(); // Calls Dog's overridden sound() because of runtime polymorphism
    }

