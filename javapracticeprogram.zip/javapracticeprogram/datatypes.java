package javapracticeprogram;
	public static void Main(String[] args) {
	public class DataTypes {
		public static void main(String[] args) {
			byte byteValue = 127;
			short shortValue = 32767;
			int intValue = 2147483647;
			long longValue = 922337834634534374L;
			float floatValue = 3;
		}
	}
	}

