package javapracticeprogram;

public class typecasting {
	    public static void main(String[] args) {
	        int intValue = 10;
	        double doubleValue = intValue; 
	        System.out.println("Original Int Value: " + intValue);
	        System.out.println("Casted Double Value: " + doubleValue);
	    
		