package javapracticeprogram;
public class BitWise{
    public static void main(String[] args) {
        int a = 5;    // binary: 0101
        int b = 3;    // binary: 0011

        // Bitwise AND (&)
        int andResult = a & b;  // 0101 & 0011 = 0001 (decimal 1)
        System.out.println("a & b = " + andResult);

        // Bitwise OR (|)
        int orResult = a | b;   // 0101 | 0011 = 0111 (decimal 7)
        System.out.println("a | b = " + orResult);

        // Bitwise XOR (^)
        int xorResult = a ^ b;  // 0101 ^ 0011 = 0110 (decimal 6)
        System.out.println("a ^ b = " + xorResult);

        // Bitwise Complement (~)
        int notA = ~a;          // ~0101 = 1010 (in 32-bit signed, it's -6)
        System.out.println("~a = " + notA);

        // Left Shift (<<)
        int leftShift = a << 1; // 0101 << 1 = 1010 (decimal 10)
        System.out.println("a << 1 = " + leftShift);

        // Right Shift (>>)
        int rightShift = a >> 1; // 0101 >> 1 = 0010 (decimal 2)
        System.out.println("a >> 1 = " + rightShift);

        // Unsigned Right Shift (>>>)
        int unsignedRightShift = a >>> 1; // 0101 >>> 1 = 0010 (decimal 2)
        System.out.println("a >>> 1 = " + unsignedRightShift);
    }
}
