package javapracticeprogram;

public class Abstraction {
	// Abstract class representing a generic Vehicle
	abstract class Vehicle {
	    // Abstract method (must be implemented by concrete subclasses)
	    abstract void accelerate();

	    // Concrete method (can be used as is or overridden by subclasses)
	    void startEngine() {
	        System.out.println("Engine started.");
	    }
	}

	// Concrete subclass implementing the abstract Vehicle class
	class Car extends Vehicle {
	    @Override
	    void accelerate() {
	        System.out.println("Car is accelerating.");
	    }
	}

	// Main class to demonstrate abstraction
	public class AbstractionExample {
	    public static void main(String[] args) {
	        // Create an object of the concrete subclass
	        Vehicle myCar = new Car();

	        // Call the concrete method inherited from the abstract class
	        myCar.startEngine();

	        // Call the abstract method implemented by the concrete subclass
	        myCar.accelerate();
	    }
	}
}
	
