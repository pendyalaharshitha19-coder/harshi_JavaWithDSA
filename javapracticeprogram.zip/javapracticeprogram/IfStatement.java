package javapracticeprogram;

public class IfStatement {

	    public static void main(String[] args) {
	        int number = 7; // Declare and initialize an integer variable

	        // Use an if statement to check if the number is greater than 0
	        if (number > 0) {
	            System.out.println("The number " + number + " is positive.");
	        }

	        System.out.println("This message is always printed, regardless of the number's value.");
	    }
	}
