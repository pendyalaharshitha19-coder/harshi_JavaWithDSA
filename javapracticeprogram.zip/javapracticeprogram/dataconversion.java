package javapracticeprogram;

public class dataconversion {

	public static void main(String[] args) {
		        int myInt = 100;
		        long myLong = myInt; // int to long (implicit)
		        double myDouble = myLong; // long to double (implicit)

		        System.out.println("Int: " + myInt);
		        System.out.println("Long: " + myLong);
		        System.out.println("Double: " + myDouble);
		    }
		}