
package javapracticeprogram;
public class PersonalInfoDisplay {
    public static void main(String[] args) {
        System.out.println("Name: John Doe");
        System.out.println("Age: 30");
        System.out.println("Occupation: Software Developer");
        System.out.println("City: New York");
    }
}