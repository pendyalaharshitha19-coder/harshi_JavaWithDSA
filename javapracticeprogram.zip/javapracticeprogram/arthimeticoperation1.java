package javapracticeprogram;

public class arthimeticoperation1 {

}
