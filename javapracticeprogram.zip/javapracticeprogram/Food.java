package javapracticeprogram;
public class Food {
    String name;
    int calories;
    public Food(String name, int calories) {
        this.name = name;
        this.calories = calories;
    }
    public void display() {
        System.out.println("Food: " + name);
        System.out.println("Calories: " + calories);
    }

    public static void main(String[] args) {
        Food pizza = new Food("Pizza", 300);
        pizza.display();
    }
}
