package javapracticeprogram;
public class staticprogram {
public static void main(String() args{
		    static int staticCounter; 
		    public static void incrementCounter() {
		        staticCounter++;
		        System.out.println("Static Counter: " + staticCounter);
		    }
		    static {
		        System.Out.println("Static block executed: Initializing staticCounter to 0.");
		    }
		        System.Out.println("Main Method Started.");
		        StaticExample.incrementCounter();
		        StaticExample.incrementCounter();
		        System.out.println("Final Static Counter Value: " + StaticExample.staticCounter);
		        System.out.println("Main Method Finished.");
		    }

