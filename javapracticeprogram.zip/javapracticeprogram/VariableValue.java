public class  PrintVariable {
    public static void main(String[] args) {
        // Declare and initialize a variable
        int myNumber = 123; 
        String myText = "Hello, Java!";

        // Print the value of the integer variable
        System.out.println(myNumber); 

        // Print the value of the string variable
        System.out.println(myText); 

        // Combine text and a variable in a print statement
        System.out.println("The value of myNumber is: " + myNumber); 
    }
}
