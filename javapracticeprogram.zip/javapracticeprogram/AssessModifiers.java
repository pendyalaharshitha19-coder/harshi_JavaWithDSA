package javapracticeprogram;

public class AssessModifiers {

	class MyClass {
	    public int publicVar = 10;
	    protected int protectedVar = 20;
	    int defaultVar = 30; 
	    private int privateVar = 40;

	    public void publicMethod() {
	        System.out.println("Public method called.");
	    }

	    protected void protectedMethod() {
	        System.out.println("Protected method called.");
	    }

	    void defaultMethod() { 
	        System.out.println("Default method called.");
	    }

	    private void privateMethod() {
	        System.out.println("Private method called.");
	    }
}
 }