package javapracticeprogram;

public class StringLength {

	 public static void main(String args[]){ 
	String s="Sachin";
	   System.out.println(s.length());//6
	  }}

