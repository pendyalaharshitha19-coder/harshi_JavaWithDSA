

package javapracticeprogram;

public class ArrayAddition {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		int y []={1,2,8,1};
		 int sum=0;
		for (int i = 0; i < y.length; i++) {  
	           sum = sum + y[i];  
	        }  
	        System.out.println("Sum of all the elements of an array: " + sum);  
	    }  
	}
