package javapracticeprogram;
public class WhileLoop Countdown {

    public static void main(String[] args) {
        // Initialize the counter variable
        int count = 5; 

        // The while loop continues as long as the 'count' is greater than 0
        while (count > 0) {
            System.out.println("Countdown: " + count);
            // Decrement the counter in each iteration
            count--; 
        }

        System.out.println("Blast off!");
    }
}


