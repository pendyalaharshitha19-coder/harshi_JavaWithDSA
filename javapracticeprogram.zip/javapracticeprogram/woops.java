package javapracticeprogram;

public class woops {

	public static void main(String[] args) {
		class Dog {
		    String name;
		    String breed;
		    public Dog(String name, String breed) {
		        this.name = name;
		        this.breed = breed;
		    }
		    public void bark() {
		        System.out.println(name + " the " + breed + " says Woof!");
		    }
		    public void displayInfo() {
		        System.out.println("Name: " + name + ", Breed: " + breed);
		    }
		}
		        Dog myDog = new Dog("Buddy", "Golden Retriever");
		        Dog anotherDog = new Dog("Lucy", "Labrador");
		        myDog.bark();
		        myDog.displayInfo();

		        anotherDog.bark();
		        anotherDog.displayInfo();
		    }
		
	}


