package javapracticeprogram;

public class Functions {

    // A method that doesn't return a value (void) and takes no arguments
    public static void greet() {
        System.out.println("Hello, Java Methods!");
    }

    // A method that takes arguments and returns an integer value
    public static int add(int num1, int num2) {
        int sum = num1 + num2;
        return sum;
    }

    public static void main(String[] args) {
        // Calling the greet method
        greet();

        // Calling the add method and storing the returned value
        int result = add(10, 5);
        System.out.println("The sum is: " + result);
    }
}
