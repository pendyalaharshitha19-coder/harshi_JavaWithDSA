package TreeAndMap;

 public class binarytree {
    int data;
    binarytree left, right;

    public binarytree(int item) {
        data = item;
        left = right = null;
    }
}

class BinaryTree {
    binarytree root;

    // Inorder Traversal (Left, Root, Right)
    void inorder(binarytree node) {
        if (node == null) return;
        inorder(node.left);
        System.out.print(node.data + " ");
        inorder(node.right);
    }

    // Preorder Traversal (Root, Left, Right)
    void preorder(binarytree node) {
        if (node == null) return;
        System.out.print(node.data + " ");
        preorder(node.left);
        preorder(node.right);
    }

    // Postorder Traversal (Left, Right, Root)
    void postorder(binarytree node) {
        if (node == null) return;
        postorder(node.left);
        postorder(node.right);
        System.out.print(node.data + " ");
    }

    public static void main(String[] args) {
        BinaryTree tree = new BinaryTree();

        // Creating nodes
        tree.root = new binarytree(1);
        tree.root.left = new binarytree(2);
        tree.root.right = new binarytree(3);
        tree.root.left.left = new binarytree(4);
        tree.root.left.right = new binarytree(5);

        // Traversals
        System.out.println("Inorder Traversal:");
        tree.inorder(tree.root);

        System.out.println("\nPreorder Traversal:");
        tree.preorder(tree.root);

        System.out.println("\nPostorder Traversal:");
        tree.postorder(tree.root);
    }
}