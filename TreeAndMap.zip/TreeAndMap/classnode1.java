package TreeAndMap;
                           

//Node should NOT be public if in same file
class Node {
 int data;
 Node left, right;

 Node(int value) {
     data = value;
     left = right = null;
 }
}

public class classnode1 {
 Node root;

 // Inorder Traversal (Left → Root → Right)
 void inorder(Node node) {
     if (node != null) {
         inorder(node.left);
         System.out.print(node.data + " ");
         inorder(node.right);
     }
 }

 // Preorder Traversal (Root → Left → Right)
 void preorder(Node node) {
     if (node != null) {
         System.out.print(node.data + " ");
         preorder(node.left);
         preorder(node.right);
     }
 }

 // Postorder Traversal (Left → Right → Root)
 void postorder(Node node) {
     if (node != null) {
         postorder(node.left);
         postorder(node.right);
         System.out.print(node.data + " ");
     }
 }

 public static void main(String[] args) {
     classnode1 tree = new classnode1();

     tree.root = new Node(1);
     tree.root.left = new Node(2);
     tree.root.right = new Node(3);
     tree.root.left.left = new Node(4);
     tree.root.left.right = new Node(5);

     System.out.println("In-order:");
     tree.inorder(tree.root);

     System.out.println("\nPre-order:");
     tree.preorder(tree.root);

     System.out.println("\nPost-order:");
     tree.postorder(tree.root);
 }
}