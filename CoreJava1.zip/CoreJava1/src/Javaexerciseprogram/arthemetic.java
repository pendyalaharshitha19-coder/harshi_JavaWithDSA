package Javaexerciseprogram;

public class arthemetic {

	public static void main(String[] args) {

			public int sum(int a, int b);
			{
				int c = a + b;
				return c;
			}

		}


	}


