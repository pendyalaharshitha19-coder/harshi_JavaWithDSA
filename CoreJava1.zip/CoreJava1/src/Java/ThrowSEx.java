package Java;

public class ThrowSEx {

	void sampleMethod()throws ArithmeticException
	{  
		throw new ArithmeticException("sorry");  
	}  
	
	public static void main(String[] args) {
		ThrowSEx obj = new ThrowSEx();
		try {
		obj.sampleMethod();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}
