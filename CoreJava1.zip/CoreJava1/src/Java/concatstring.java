package Java;

public class concatstring {

	public static void main(String[] args) {
		String s1,s2,s3;
		s1="hai";
		s2="welcome";
		s3=s1+s2;
		System.out.println("enter the string concat value:"+s3);

	}

}
