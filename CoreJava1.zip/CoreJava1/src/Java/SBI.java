package Java;

public class SBI extends BankP{
	float getRateOfInterest()
	{
		return 8.4f;
	}  
}
