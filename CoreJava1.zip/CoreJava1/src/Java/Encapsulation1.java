package Java;

public class Encapsulation1 {
	
	private String name;		//local Variable
	
	public String getName()  //getting
	{
	      return name;
	}
	
	public void setName(String newName)	//setting  newName=vivek
	 {						//instance variable
		    name = newName;   //vivek
	 }
}


		
		
		


